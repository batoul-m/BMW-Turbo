import React from "react";
import ReactDOM from "react-dom";
import Home from "./Home";

//ReactDOM.render(<Home />, document.querySelector("#root"));
const rootElement = document.getElementById("root");
ReactDOM.render(<Home />, rootElement);
