import React from "react";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Tabs from "@material-ui/core/Tabs";
import Image from "./background_web.png"; // Import using relative path
import "./Home.css";

export default class Home extends React.Component {
  render() {
    return (
      <div className="background" style={{ backgroundImage: `url(${Image})` }}>
        <header
          className="speak"
          style={{
            fontSize: 30
          }}
        >
          Speak Up
        </header>

        <Button
          size="larg"
          variant="outlined"
          disableRipple
          style={{
            backgroundColor: "#eeeeee",
            top: 100,
            left: 160,
            fontFamily: "Arial",
            fontSize: 14,
            padding: "7px 13px"
          }}
        >
          LOG IN
        </Button>
        <Button
          variant="outlined"
          size="larg"
          disabled
          style={{
            left: 200,
            top: 100,
            border: "2px solid",
            //textColor: "#ffffff",
            //ContrastText: "#000000"
            fontFamily: "Arial",
            fontSize: 14,
            padding: "7px 13px"
          }}
        >
          SIGN UP
        </Button>
        <div className="hry">
          <Typography
            variant="body2"
            component="p"
            style={{ right: 5, left: 300, top: 200, button: 5, fontSize: 16 }}
          >
            Our Speak up for the people who can’t talk well,we try to make them
            Speak fluently or make them speak in a better way, by giving them
            some exercis
          </Typography>
        </div>
      </div>
    );
  }
}
